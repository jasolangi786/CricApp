package com.example.android.cricapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    /**
     * G variables to track score of both teams and out players
     */

    int teamPakistan = 0;
    int teamIndia = 0;
    int teamPakOut = 0;
    int teamIndOut = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    /**
     * increment of six in score till one for team Pak
     */
    public void addSixForTeamPak(View v) {
        teamPakistan = teamPakistan + 6;
        displayForTeamA(teamPakistan);
    }


    public void addFourForTeamPak(View v) {
        teamPakistan = teamPakistan + 4;
        displayForTeamA(teamPakistan);
    }


    public void addThreeForTeamPak(View v) {
        teamPakistan = teamPakistan + 3;
        displayForTeamA(teamPakistan);
    }

    public void addTwoForTeamPak(View v) {
        teamPakistan = teamPakistan + 2;
        displayForTeamA(teamPakistan);
    }

    public void addOneForTeamPak(View v) {
        teamPakistan = teamPakistan + 1;
        displayForTeamA(teamPakistan);
    }

    /**
     * increment of six in score till one for team India
     */
    public void addSixForTeamIndia(View v) {
        teamIndia = teamIndia + 6;
        displayForTeamB(teamIndia);
    }


    public void addFourForTeamIndia(View v) {
        teamIndia = teamIndia + 4;
        displayForTeamB(teamIndia);
    }


    public void addThreeForTeamIndia(View v) {
        teamIndia = teamIndia + 3;
        displayForTeamB(teamIndia);
    }

    public void addTwoForTeamIndia(View v) {
        teamIndia = teamIndia + 2;
        displayForTeamB(teamIndia);
    }


    public void addOneForTeamIndia(View v) {
        teamIndia = teamIndia + 1;
        displayForTeamB(teamIndia);
    }

    /**
     * increment of out players of team Pak
     */
    public void addOutForTeamPakistan(View v) {
        teamPakOut = teamPakOut + 1;
        displayOutTeamPak(teamPakOut);
    }

    /**
     * increment of out players of team India
     */
    public void addOutForTeamIndia(View v) {
        teamIndOut = teamIndOut + 1;
        displayOutTeamInd(teamIndOut);
    }

    /**
     * rest score and out players
     */
    public void resetScore(View v) {
        teamPakistan = 0;
        teamIndia = 0;
        teamPakOut = 0;
        teamIndOut = 0;
        displayForTeamA(teamPakistan);
        displayForTeamB(teamIndia);
        displayOutTeamPak(teamPakOut);
        displayOutTeamInd(teamIndOut);
    }

    public void displayForTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_pakistan);
        scoreView.setText(String.valueOf(score));
    }

    public void displayForTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_india);
        scoreView.setText(String.valueOf(score));
    }

    public void displayOutTeamPak(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_pakistan_out);
        scoreView.setText(String.valueOf(score));
    }

    public void displayOutTeamInd(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_india_out);
        scoreView.setText(String.valueOf(score));
    }
}